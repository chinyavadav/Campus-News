<?php
include("connection.php");
$posts=array();
$date=date('Y-m-d H:i:s');
if(isset($_GET["fid"])){
	$faculty_id=mysqli_real_escape_string($conn,$_GET["fid"]);
	$statement="SELECT * FROM tblposts JOIN tblfaculties ON tblposts.fldfaculty_id=tblfaculties.fldfaculty_id WHERE tblposts.fldfaculty_id='$faculty_id' ORDER BY fldpost_id DESC";
}else{
	$statement="SELECT * FROM tblposts JOIN tblfaculties ON tblposts.fldfaculty_id=tblfaculties.fldfaculty_id ORDER BY fldpost_id DESC";
}

$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($query)){          
	$posts[]=$record;
}
echo json_encode($posts);   
?>