<?php
include("connection.php");
$posts=array();
$date=date('Y-m-d');
$statement="SELECT * FROM tblposts JOIN tblfaculties ON tblposts.fldfaculty_id=tblfaculties.fldfaculty_id WHERE tblposts.fldtimestamp>'$date' ORDER BY fldpost_id DESC";

$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($query)){          
	$posts[]=$record;
}
echo json_encode($posts);   
?>