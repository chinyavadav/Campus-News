<?php
include("connection.php");
$faculties=array();
$date=date('Y-m-d H:i:s');
$statement="SELECT * FROM tblfaculties";
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($query)){          
	$faculties[]=$record;
}
echo json_encode($faculties);   
?>