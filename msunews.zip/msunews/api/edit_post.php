<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata) && isset($_GET["post_id"])) {
	        $request = json_decode($postdata);
	        $post_id=mysqli_real_escape_string($conn,$_GET["post_id"]);
	        $title=mysqli_real_escape_string($conn,$request->title);
	        $post=mysqli_real_escape_string($conn,$request->post);
	        $date=date('Y-m-d H:i:s');
	        $picture=$request->picture;
	        $statement="UPDATE tblposts SET fldpost_title='$title', fldpost='$post',fldpicture='$picture' WHERE fldpost_id='$post_id'";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>