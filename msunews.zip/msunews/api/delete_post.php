<?php
include("connection.php");
header('Content-Type: application/json');
if(isset($_GET["post_id"])){
	$post_id=mysqli_real_escape_string($conn,$_GET["post_id"]);
	$statement="DELETE FROM tblcomments WHERE fldpost_id='$post_id'";
	$query=mysqli_query($conn,$statement) or die(failed());

	$statement="DELETE FROM tblposts WHERE fldpost_id='$post_id'";
	$query=mysqli_query($conn,$statement) or die(failed());
	$response=array("response"=>"success");
	echo json_encode($response);	    
}

function failed(){
	$response=array("response"=>"failed");
	echo json_encode($response);
}
?>