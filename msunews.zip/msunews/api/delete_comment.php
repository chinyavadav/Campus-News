<?php
include("connection.php");
if(isset($_GET["commentId"])){        
	$commentId = mysqli_real_escape_string($conn,$_GET["commentId"]);
	$statement="DELETE FROM tblcomments WHERE fldcomment_id='$commentId'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$response['response']='success';
} else{
	$response=array("response"=>"failed");
}
echo json_encode($response);

?>