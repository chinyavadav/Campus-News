<?php
	include("connection.php");
    $users=array();
    if(isset($_GET["userid"])){
        $userid=mysqli_real_escape_string($conn,$_GET["userid"]);
        $statement="SELECT * FROM tblusers WHERE flduser_id!='$userid'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        while($record=mysqli_fetch_assoc($query)){
            $temp=array();
            $temp["userid"]=$record['flduser_id'];
            $stmt="SELECT * FROM tblstaff WHERE flduser_id='$record[flduser_id]'";
            $qry=mysqli_query($conn,$stmt) or die(mysqli_error($conn));
            if(mysqli_num_rows($qry)==1){
                $temp["type"]='FacultyAdmin';
            }else{
                $temp["type"]='Student';
            }            
            $temp["fullname"]=$record['fldforename'].' '.$record['fldsurname'];
            $users[]=$temp;
        }
    }
    echo json_encode($users);
?>