<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	        $request=json_decode($postdata);
	        $faculty_id=mysqli_real_escape_string($conn,$request->faculty_id);
	        $title=mysqli_real_escape_string($conn,$request->title);
	        $post=mysqli_real_escape_string($conn,$request->post);
	        $date=date('Y-m-d H:i:s');
	        $picture=$request->picture;
	        $statement="INSERT INTO tblposts(fldfaculty_id,fldpost_title,fldpost,fldpicture,fldtimestamp) VALUES('$faculty_id','$title','$post','$picture','$date')";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>