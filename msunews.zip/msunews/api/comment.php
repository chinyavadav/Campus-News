<?php
	include("connection.php");
	if(isset($_GET["post_id"]) && isset($_GET["from"]) && isset($_GET["comment"])){
		$post_id=mysqli_real_escape_string($conn,$_GET["post_id"]);  
        $from=mysqli_real_escape_string($conn,$_GET["from"]);        
        $comment=mysqli_real_escape_string($conn,$_GET["comment"]);
        $timestamp=date('Y-m-d H:i:s');
        $statement="INSERT INTO tblcomments(flduser_id,fldpost_id,fldcomment,fldtimestamp,fldvisible) VALUES('$from','$post_id','$comment','$timestamp','true')";
	    $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	    $response=array("response"=>"success");
	    echo json_encode($response);
	}
		    
?>