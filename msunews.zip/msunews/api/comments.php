<?php
	include("connection.php");
    if(isset($_GET["post_id"])){
        $comments=array();
        $array=array();
        $postid=mysqli_real_escape_string($conn,$_GET["post_id"]);
        $statement="SELECT * FROM tblcomments WHERE fldpost_id='$postid'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        
        while($record=mysqli_fetch_assoc($query)){
            $temp=array();
            $temp["commentId"]=$record["fldcomment_id"];
            $temp["fromUserId"]=$record["flduser_id"];          
            $temp["time"]=$record["fldtimestamp"];
            $temp["comment"]=$record["fldcomment"];
            $temp["visible"]=$record["fldvisible"];

            $statement="SELECT * FROM tblusers WHERE flduser_id='$record[flduser_id]'";
            $client_query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            while($client=mysqli_fetch_assoc($client_query)){
                if($client["flduser_id"]==$record["flduser_id"]){
                    $temp["fromUserName"]=$client['fldforename'].' '.$client['fldsurname'];
                }
            }
            $array[]=$temp;
        }
        $comments["array"]=$array;
        echo json_encode($comments);
    }
?>